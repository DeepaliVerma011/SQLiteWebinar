package com.example.sqllitewebinar

data class Todo(var task:String,var done:Boolean)